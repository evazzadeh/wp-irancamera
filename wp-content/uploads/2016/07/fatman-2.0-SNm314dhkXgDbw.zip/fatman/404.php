<?php get_header(); ?>
<a href=" <?php bloginfo('url'); ?>">
<div id="page404">
 	<div></div>
</div>
</a>